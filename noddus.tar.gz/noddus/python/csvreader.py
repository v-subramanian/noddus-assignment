#https://sqliteonline.com/ -- use this to cross check the data using online sql lite viewer

import sqlite3
import sys
import os

def createConnection(dbFile):
    try:
        conn = sqlite3.connect(dbFile)
        return conn
    except Error as e:
        print(e)
 
    return None;


def tableExists(cursor, tableName):

    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='"+tableName+"'")
    
    row = cursor.fetchone()
    
    if row is None:
        return False;
    
    return True;


def cmdLineParamAvailable():
    if len(sys.argv) == 2:
        return True
    else:
        return False;


def fileExists(fileName):
    return os.path.isfile('./'+fileName)


def emptyFile(fileName):
    statinfo = os.stat(fileName)
    if statinfo.st_size == 0:
        return True
    return False;


def main():
    
    if not cmdLineParamAvailable() :
        print("ERROR: missing csv file name")
        return
    
    csvFile = sys.argv[1] 
    
    if not fileExists(csvFile):
        print("ERROR: csv file doesnt exist in current directory")
        return
    
    if emptyFile(csvFile):
        print("ERROR: csv file is empty. It must contain atleast one row")
        return
   
    conn = createConnection('contacts.db')
    
    if conn is None:
        print("ERROR: unable to open database")
        return
    
    cursor = conn.cursor()

    if not tableExists(cursor, "contacts"):
        cursor.execute('''CREATE TABLE contacts (name text, email text, mobile text)''')
        conn.commit()
    else:
        print("Table contacts already exists. Skipping table creation...")
        
    rows = 0
    expectedFieldCount=3
    
    file = open(csvFile,"r")
    for line in file:
        fields = line.strip().split(",")
        
        #exactly 3 fields are expected
        if len(fields) != expectedFieldCount :
            print "Mismatch in number of fields found in csv file in this row, skipping..."
            continue;
        
        fstr = "','".join(fields)
        fstr = "'"+fstr+"'"
        
        try:
            cursor.execute("INSERT INTO contacts VALUES ("+fstr+")")
            rows = rows+1
        except sqlite3.OperationalError, msg:
            print "Unable to insert row with values"+fstr
        
    print("Total number of rows inserted: "+str(rows))
    
    file.close()

    conn.commit()

    conn.close()
        
    return;

#main function execution starts here
#comment when running test script, uncomment when running as stand-alone
main()
