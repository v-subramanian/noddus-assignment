import unittest

from csvreader import fileExists
from csvreader import emptyFile

class TestCSVReader(unittest.TestCase):

    def test_fileExists(self):
        res = fileExists("test.csv")
        self.assertEqual(res, True)
        
    def test_emptyFile(self):
        res = emptyFile("empty.csv")
        self.assertEqual(res, True)
        
    #database related test cases pending


if __name__ == '__main__':
    unittest.main()
