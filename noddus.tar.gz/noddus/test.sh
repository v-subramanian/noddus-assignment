#docker pull adbourne/docker-java-maven-protobuf:v3.5-8-3.5.0
image="java"
container="jmpc"
port="9000"
docker pull $(echo $image)
#docker run --name jmpc --expose=9000 -d adbourne/docker-java-maven-protobuf:v3.5-8-3.5.0 tail -f /dev/null
docker run --name $(echo $container) --expose=$(echo $port) -d $(echo $image) tail -f /dev/null
docker cp ./SimpleJavaHttpServer/. $(echo $container):/home
echo please open url: http://$(docker inspect --format '{{ .NetworkSettings.IPAddress }}' $(echo $container)):$(echo $port) in browser...
docker exec $(echo $container) bash -c 'cd /home/target/classes; java com/happylife/demo/Main'

#helpful to remove old/exited containers
#docker rm $(docker ps -qa --no-trunc --filter "status=exited")

#attach to container and get shell 
#docker exec -it jmpc /bin/bash
